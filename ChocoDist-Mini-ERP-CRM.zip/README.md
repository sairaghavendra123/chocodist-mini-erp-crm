# ChocoDist - Chocolate Wholesale & Distribution Operations Portal

A clean, professional, full-stack **Chocolate Wholesale & Distribution Operations Portal** built for B2B chocolate distributors, suppliers, and wholesale operations. This project is structured and documented for a **student technical interview submission**, demonstrating strong core fundamentals in full-stack architecture, relational database transactions, role-based security, and responsive B2B software design.

---

## 📋 Table of Contents
- [Tech Stack](#-tech-stack)
- [Key Features & Modules](#-key-features--modules)
- [Role-Based Access Control (RBAC)](#-role-based-access-control-rbac)
- [Project Structure](#-project-structure)
- [Environment Variables](#-environment-variables)
- [Local Installation & Setup](#-local-installation--setup)
- [Demo Account Credentials](#-demo-account-credentials)
- [REST API Reference](#-rest-api-reference)
- [Business Logic & Transaction Safety](#-business-logic--transaction-safety)
- [Deployment Instructions (Vercel + Render + Supabase/Neon)](#-deployment-instructions)
- [Architecture Explanation](#-architecture-explanation)
- [Known Limitations](#-known-limitations)
- [🎓 How to Explain This Project in an Interview](#-how-to-explain-this-project-in-an-interview)

---

## 🛠 Tech Stack

### Frontend
- **Framework**: React 18 + TypeScript + Vite
- **Styling**: Vanilla CSS (Custom Design System, Chocolate/Brown Corporate Accents, Light B2B Theme)
- **Icons**: Lucide React (`lucide-react`)
- **State Management**: React Context (`AuthContext`)

### Backend
- **Runtime & Server**: Node.js + Express.js + TypeScript
- **Database ORM**: Prisma ORM (PostgreSQL datasource / SQLite local dev)
- **Authentication**: JWT (`jsonwebtoken`) with `Authorization: Bearer <token>`
- **Password Hashing**: `bcryptjs`
- **Validation**: Zod schema validation

### Database & Deployment
- **Database**: PostgreSQL (Supabase / Neon compatible)
- **Frontend Hosting**: Vercel
- **Backend Hosting**: Render

---

## 🌟 Key Features & Modules

### 1. Role-Based Login & Authentication
- Secure JWT-based authentication with bcrypt password encryption.
- 4 distinct internal employee roles: **Admin**, **Sales**, **Warehouse**, **Accounts**.
- Role comes exclusively from the authenticated session (no manual header role switcher).
- 1-Click Demo Login buttons on login screen for fast presentation.

### 2. Executive Dashboard
- 4 KPI Metric Cards: Total Customers, Total Products, Low Stock Products, Total Sales Challans.
- Summary Tables for Recent Sales Challans and Low Stock Products needing inward replenishment.

### 3. Customer CRM Module
- Comprehensive retail & wholesale customer profiles: Customer Name, Mobile, Email, Business Name, GST Number, Customer Type (*Retail, Wholesale, Distributor*), Address, Status (*Lead, Active, Inactive*), Follow-up Date, and Notes.
- Search and filtering by status and customer type.
- Add/Edit Customer Modals and CRM Follow-up Remarks Log entry.

### 4. Product & Inventory Module
- Wholesale chocolate catalog: Product Name (*Dairy Milk, 5 Star, Perk, Gems, Dairy Milk Silk, Munch, KitKat, Fuse, Bournville, Milkybar*), SKU (`CHO-DM-001`), Category (*Milk Chocolate, Dark Chocolate, Wafer Chocolate, Premium Chocolate, Chocolate Bars, Chocolate Pouches*), Unit Price, Current Stock (in units), Minimum Stock Alert Quantity, Warehouse Location.
- Visual **Low Stock Warnings** when inventory drops below alert thresholds (*Dairy Milk Silk*, *Fuse*).
- Quick **Manual Stock Adjustment** (Inward / Outward) with supplier/replenishment reason tracking.

### 5. Sales Challan Module
- Step-by-step Sales Challan Builder: Business customer selector, dynamic chocolate product line items, real-time total quantity & total value calculation.
- Auto-generated unique Challan Numbers (e.g. `CH-2026-001`).
- Save as **Draft** (no stock deduction) vs **Confirm Challan** (atomic stock deduction & stock movement log creation).
- **Product Snapshot Preservation**: Stores product snapshot data (`productName`, `sku`, `unitPrice`) inside `ChallanItem` to preserve historical order records even if the catalog changes later.

---

## 🔐 Role-Based Access Control (RBAC)

| Role | Dashboard | Customers CRM | Products Catalog | Inventory Logs | Sales Challans |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Admin** | ✅ Full | ✅ Full | ✅ Full | ✅ Full | ✅ Full |
| **Sales** | ✅ View | ✅ Full | ❌ No Access | ❌ No Access | ✅ Full |
| **Warehouse** | ✅ View | ❌ No Access | ✅ Full | ✅ Full | ❌ No Access |
| **Accounts** | ✅ View | ✅ Full | ❌ No Access | ❌ No Access | ✅ Full |

---

## 📁 Project Structure

```
mini-erp-crm/
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma        # Prisma ORM Schema (User, Customer, Product, StockMovement, Challan, ChallanItem)
│   │   └── seed.ts              # Seed script with realistic chocolate wholesale demo data
│   ├── src/
│   │   ├── config/              # Prisma Client instance
│   │   ├── middleware/          # Auth JWT & RBAC role authorization middleware
│   │   ├── routes/              # Express REST API routes (auth, customers, products, inventory, challans, dashboard)
│   │   ├── types/               # TypeScript domain interfaces & Express declaration
│   │   └── index.ts             # Express app entry point
│   ├── package.json
│   ├── tsconfig.json
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/          # Sidebar, TopBar, Modal components
│   │   ├── context/             # AuthContext (JWT, user state, permission checks)
│   │   ├── pages/               # LoginPage, DashboardPage, CustomersPage, ProductsPage, InventoryPage, ChallansPage
│   │   ├── services/            # Centralized API fetch wrapper with token injection
│   │   ├── types/               # Shared TypeScript data types
│   │   ├── App.tsx              # Layout & route guard rendering
│   │   ├── index.css            # Custom CSS Design System
│   │   └── main.tsx             # React entry point
│   ├── package.json
│   ├── vite.config.ts
│   └── .env.example
├── README.md
└── .gitignore
```

---

## 🔑 Demo Account Credentials

Use these pre-configured credentials to test all 4 roles in the portal:

| Role | Email | Password | Allowed Access |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin@chocodist.com` | `ChocoAdmin#2026!A7` | Everything |
| **Sales** | `sales@chocodist.com` | `ChocoSales#2026!B8` | Customers CRM, Sales Challans |
| **Warehouse** | `warehouse@chocodist.com` | `ChocoWarehouse#2026!C9` | Products, Stock Adjustments, Inventory Logs |
| **Accounts** | `accounts@chocodist.com` | `ChocoAccounts#2026!D4` | Customers CRM, Sales Challans |

---

## ⚙️ Environment Variables

### Backend (`/backend/.env`)
```env
PORT=5001
NODE_ENV=development
DATABASE_URL="file:./dev.db" # Or PostgreSQL: postgresql://user:pass@host:5432/dbname?sslmode=require
JWT_SECRET="mini_erp_crm_super_secret_jwt_key_2026"
FRONTEND_URL="http://127.0.0.1:5173"
```

### Frontend (`/frontend/.env`)
```env
VITE_API_BASE_URL="/api"
```

---

## 🚀 Local Installation & Setup

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn

### 1. Backend Setup
```bash
# Navigate to backend folder
cd backend

# Install dependencies
npm install

# Push database schema & generate Prisma Client
npx prisma db push

# Seed demo data (creates 4 ChocoDist role accounts, 8 customers, 10 products, challans)
npm run seed

# Start backend server in dev mode
npm run dev
```
Backend server will run at `http://localhost:5001`.

### 2. Frontend Setup
```bash
# Navigate to frontend folder in a new terminal
cd frontend

# Install dependencies
npm install

# Start Vite development server
npm run dev
```
Frontend app will open at `http://127.0.0.1:5173`.

---

## 📡 REST API Reference

### Authentication
- `POST /api/auth/login` - Authenticate email & password, returns JWT token + user profile.
- `GET /api/auth/me` - Fetch currently authenticated user profile.

### Dashboard
- `GET /api/dashboard/stats` - Fetch KPI stats, low-stock items, and recent challans.

### Customer CRM
- `GET /api/customers` - List customers with search (`q`), status, and type filters.
- `POST /api/customers` - Create new customer.
- `GET /api/customers/:id` - Fetch single customer with challan history.
- `PUT /api/customers/:id` - Update customer info or append follow-up notes.
- `DELETE /api/customers/:id` - Delete customer (if no associated challans exist).

### Products & Inventory
- `GET /api/products` - List products with search (`q`), category, and `lowStock=true` filter.
- `POST /api/products` - Add chocolate product to inventory (*Warehouse & Admin*).
- `GET /api/products/:id` - Fetch single product details & stock log history.
- `PUT /api/products/:id` - Update product details (*Warehouse & Admin*).
- `GET /api/inventory/movements` - View complete stock movement history log.
- `POST /api/inventory/adjust` - Record manual stock adjustment IN/OUT (*Warehouse & Admin*).

### Sales Challans
- `GET /api/challans` - List sales challans with customer details.
- `POST /api/challans` - Create sales challan (Draft or Confirmed).
- `GET /api/challans/:id` - View sales challan invoice snapshot details.
- `PUT /api/challans/:id/confirm` - Confirm draft sales challan (triggers atomic stock deduction).
- `PUT /api/challans/:id/cancel` - Cancel sales challan.

---

## 💡 Business Logic & Transaction Safety

1. **Negative Stock Prevention**:
   - Stock levels cannot drop below `0`.
   - When a sales challan is confirmed, the backend validates available stock for every line item.
   - If stock is insufficient (e.g. Requested: 30, Available: 20), the API rejects the request with HTTP 400 and an explicit error message: `"Insufficient stock for Dairy Milk"`.

2. **Atomic Database Transactions**:
   - Challan confirmation uses `prisma.$transaction(...)`.
   - In a single atomic operation:
     1. Stock availability is verified.
     2. Product stock is decremented.
     3. Stock movement records (`OUT`) are generated.
     4. Challan status is updated to `CONFIRMED`.
   - If any step fails, the entire transaction rolls back cleanly.

3. **Product Information Snapshots**:
   - When creating a challan, `ChallanItem` stores snapshot data (`productName`, `sku`, `unitPrice`, `quantity`, `totalPrice`).
   - This ensures that even if a chocolate product's price or name is updated in the catalog later, historical sales challans maintain exact historical accuracy.

---

## 🌐 Deployment Instructions

### 1. Database Deployment (Supabase or Neon PostgreSQL)
1. Create a free PostgreSQL database on [Supabase](https://supabase.com) or [Neon](https://neon.tech).
2. Copy the Connection String URI (`postgresql://postgres:[PASSWORD]@[HOST]:5432/[DB]?sslmode=require`).
3. In `backend/prisma/schema.prisma`, ensure `provider = "postgresql"`.
4. Run `npx prisma db push` and `npm run seed` with the PostgreSQL connection string set in `DATABASE_URL`.

### 2. Backend Deployment (Render)
1. Create a new **Web Service** on [Render](https://render.com) linked to your GitHub repository.
2. Set Root Directory to `backend`.
3. Build Command: `npm install && npx prisma generate && npm run build`
4. Start Command: `npm run start`
5. Add Environment Variables: `DATABASE_URL`, `JWT_SECRET`, `NODE_ENV=production`, `FRONTEND_URL`.

### 3. Frontend Deployment (Vercel)
1. Import your repository into [Vercel](https://vercel.com).
2. Set Root Directory to `frontend`.
3. Build Command: `npm run build`
4. Environment Variable: `VITE_API_BASE_URL=https://your-backend.onrender.com/api`

---

## 🎓 How to Explain This Project in an Interview

Here are 10 key technical points to explain during an interview presentation:

1. **Project Purpose**: *"I built ChocoDist, a Chocolate Wholesale & Distribution Operations Portal, to digitize B2B order dispatches, inventory stock movements, and retail customer CRM follow-ups for wholesale distributors."*
2. **Architecture**: *"It follows a clean decoupled client-server architecture with a React Vite frontend and a RESTful Express TypeScript backend using Prisma ORM."*
3. **Role-Based Access Control**: *"I implemented RBAC across 4 roles (Admin, Sales, Warehouse, Accounts). User roles originate strictly from authenticated JWT sessions. On the backend, custom middleware verifies JWTs and restricts API endpoints, while the frontend dynamically renders navigation links accordingly."*
4. **Data Integrity & Snapshots**: *"To prevent historical invoice corruption, I designed `ChallanItem` to store product snapshot data—capturing the exact chocolate product name, SKU, and unit price at the time of sale."*
5. **ACID Transaction Safety**: *"When confirming a sales challan, I wrapped stock verification, inventory reduction, stock movement log creation, and status updates inside a Prisma interactive transaction (`$transaction`). If stock is insufficient or a DB constraint fails, everything rolls back atomically."*
6. **Negative Stock Guard**: *"The API explicitly validates available stock before decrementing, returning clean HTTP 400 responses with descriptive error messages like 'Insufficient stock for Dairy Milk'."*
7. **CRM Capabilities**: *"The customer CRM tracks retail shops, supermarkets, and distributors, handling follow-up dates and an append-only notes timeline for sales calls."*
8. **UI/UX Design**: *"I built a custom B2B corporate design system with subtle chocolate-brown accents (`#5c3a21`), responsive data tables, low-stock warning tags, and clean modal dialogs without relying on heavy UI library bloat."*
9. **Seed Script**: *"I created an automated Prisma seed script containing realistic Indian wholesale chocolate demo data (Dairy Milk, 5 Star, KitKat, Bournville, etc.) for instant testing across all 4 user roles."*
10. **Deployment Ready**: *"The app is configured for Vercel on the frontend, Render on the backend, and Supabase/Neon PostgreSQL for the database layer with standard environment variables."*
