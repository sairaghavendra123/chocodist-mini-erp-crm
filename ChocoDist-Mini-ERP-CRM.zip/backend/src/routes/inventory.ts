import { Router, Request, Response } from 'express';
import { prisma } from '../config/db';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { z } from 'zod';

const router = Router();

router.use(authenticateToken);
router.use(authorizeRoles('WAREHOUSE'));

const adjustStockSchema = z.object({
  productId: z.string().min(1, 'Product ID is required'),
  quantityChanged: z.number().int().positive('Quantity changed must be a positive integer'),
  movementType: z.enum(['IN', 'OUT'], {
    errorMap: () => ({ message: "Movement type must be 'IN' or 'OUT'" }),
  }),
  reason: z.string().min(3, 'Reason for stock movement is required'),
});

// GET /api/inventory/movements - Fetch stock movement log
router.get('/movements', async (req: Request, res: Response): Promise<void> => {
  try {
    const { productId } = req.query;

    const whereClause: any = {};
    if (productId && typeof productId === 'string') {
      whereClause.productId = productId;
    }

    const movements = await prisma.stockMovement.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      include: {
        product: {
          select: { id: true, name: true, sku: true, category: true },
        },
        createdBy: {
          select: { id: true, name: true, role: true },
        },
      },
    });

    res.json({
      success: true,
      data: movements,
    });
  } catch (error) {
    console.error('Error fetching inventory movements:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch inventory movements log',
    });
  }
});

// POST /api/inventory/adjust - Manual stock entry (IN / OUT)
router.post('/adjust', async (req: Request, res: Response): Promise<void> => {
  try {
    const parseResult = adjustStockSchema.safeParse(req.body);
    if (!parseResult.success) {
      res.status(400).json({
        success: false,
        message: parseResult.error.errors[0].message,
      });
      return;
    }

    const { productId, quantityChanged, movementType, reason } = parseResult.data;
    const userId = req.user!.id;

    // Use Prisma transaction for atomic update
    const result = await prisma.$transaction(async (tx) => {
      const product = await tx.product.findUnique({ where: { id: productId } });
      if (!product) {
        throw new Error(`Product not found (ID: ${productId})`);
      }

      let newStock = product.currentStock;
      if (movementType === 'IN') {
        newStock += quantityChanged;
      } else {
        if (product.currentStock < quantityChanged) {
          throw new Error(
            `Insufficient stock for '${product.name}'. Current stock: ${product.currentStock}, Requested reduction: ${quantityChanged}`
          );
        }
        newStock -= quantityChanged;
      }

      const updatedProduct = await tx.product.update({
        where: { id: productId },
        data: { currentStock: newStock },
      });

      const movement = await tx.stockMovement.create({
        data: {
          productId,
          quantityChanged,
          movementType,
          reason,
          createdById: userId,
        },
        include: {
          product: { select: { name: true, sku: true } },
          createdBy: { select: { name: true } },
        },
      });

      return { product: updatedProduct, movement };
    });

    res.json({
      success: true,
      message: `Stock successfully adjusted (${movementType} ${quantityChanged})`,
      data: result,
    });
  } catch (error: any) {
    console.error('Error adjusting stock:', error);
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to adjust stock',
    });
  }
});

export default router;
