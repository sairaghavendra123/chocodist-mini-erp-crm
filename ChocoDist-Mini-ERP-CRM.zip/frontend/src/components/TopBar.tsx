import React from 'react';
import { useAuth } from '../context/AuthContext';
import { User, LogOut, Bell } from 'lucide-react';

interface TopBarProps {
  activeTab: string;
}

const tabMetaData: Record<string, { title: string; subtitle: string }> = {
  dashboard: {
    title: 'Dashboard',
    subtitle: "Overview of your chocolate distribution operations.",
  },
  customers: {
    title: 'Customers',
    subtitle: 'Manage your retail and wholesale business relationships.',
  },
  products: {
    title: 'Products',
    subtitle: 'Manage chocolate products, pricing and stock levels.',
  },
  inventory: {
    title: 'Inventory & Stock Movements',
    subtitle: 'Track warehouse inventory levels and stock movement audit logs.',
  },
  challans: {
    title: 'Sales Challans',
    subtitle: 'Manage customer dispatch documents and delivery orders.',
  },
};

export const TopBar: React.FC<TopBarProps> = ({ activeTab }) => {
  const { user, logout } = useAuth();
  const currentMeta = tabMetaData[activeTab] || {
    title: 'ChocoDist Operations',
    subtitle: 'Chocolate Wholesale & Distribution Platform',
  };

  return (
    <header className="topbar">
      <div className="topbar-left">
        <h1 className="topbar-title">{currentMeta.title}</h1>
        <p className="topbar-subtitle">{currentMeta.subtitle}</p>
      </div>

      <div className="topbar-right">
        {/* Quick Notification Icon */}
        <button className="topbar-icon-btn" title="Notifications">
          <Bell size={18} />
          <span className="notification-dot"></span>
        </button>

        {/* User Profile & Role Tag derived exclusively from JWT Session */}
        <div className="user-profile">
          <div className="user-avatar">
            {user?.name ? user.name.charAt(0).toUpperCase() : <User size={18} />}
          </div>
          <div className="user-info">
            <span className="user-name">{user?.name}</span>
            <span className="user-role-badge">{user?.role}</span>
          </div>
        </div>

        <button
          className="btn btn-secondary btn-sm"
          onClick={logout}
          title="Sign out of system"
          style={{ padding: '0.4rem 0.65rem' }}
        >
          <LogOut size={16} />
        </button>
      </div>
    </header>
  );
};
