import React, { useEffect, useState } from 'react';
import { fetchApi } from '../services/api';
import { StockMovement, Product } from '../types';
import { ArrowUpRight, ArrowDownLeft, Calendar, User as UserIcon, Boxes, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';

export const InventoryPage: React.FC = () => {
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [movementFilter, setMovementFilter] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [movRes, prodRes] = await Promise.all([
        fetchApi<StockMovement[]>('/inventory/movements'),
        fetchApi<Product[]>('/products'),
      ]);

      if (movRes.success && movRes.data) {
        setMovements(movRes.data);
      }
      if (prodRes.success && prodRes.data) {
        setProducts(prodRes.data);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load stock movements log');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredMovements = movementFilter
    ? movements.filter((m) => m.movementType === movementFilter)
    : movements;

  const totalProducts = products.length;
  const lowStockCount = products.filter((p) => p.currentStock <= p.minStockAlert && p.currentStock > 0).length;
  const outOfStockCount = products.filter((p) => p.currentStock === 0).length;
  const healthyStockCount = Math.max(0, totalProducts - lowStockCount - outOfStockCount);

  return (
    <div>
      {/* Top Warehouse KPI Cards */}
      <div className="stats-grid" style={{ marginBottom: '1.5rem' }}>
        <div className="stat-card">
          <div>
            <div className="stat-val">{totalProducts}</div>
            <div className="stat-label">Total Products</div>
          </div>
          <div className="stat-icon-wrapper stat-icon-brown">
            <Boxes size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div>
            <div className="stat-val" style={{ color: '#16a34a' }}>{healthyStockCount}</div>
            <div className="stat-label">Healthy Stock</div>
          </div>
          <div className="stat-icon-wrapper stat-icon-green">
            <CheckCircle2 size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div>
            <div className="stat-val" style={{ color: lowStockCount > 0 ? '#d97706' : '#0f172a' }}>{lowStockCount}</div>
            <div className="stat-label">Low Stock Alert</div>
          </div>
          <div className="stat-icon-wrapper stat-icon-amber">
            <AlertTriangle size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div>
            <div className="stat-val" style={{ color: outOfStockCount > 0 ? '#dc2626' : '#0f172a' }}>{outOfStockCount}</div>
            <div className="stat-label">Out of Stock</div>
          </div>
          <div className="stat-icon-wrapper stat-icon-amber" style={{ background: '#fef2f2', color: '#dc2626', borderColor: '#fca5a5' }}>
            <XCircle size={22} />
          </div>
        </div>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <div className="card-table-wrapper">
        <div className="card-header">
          <h3 className="card-title">Stock Movement Audit Log</h3>
          <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
            <span style={{ fontSize: '0.8rem', color: '#64748b', fontWeight: 500 }}>Type:</span>
            <select
              className="select-input"
              style={{ fontSize: '0.8rem', padding: '0.35rem 0.6rem' }}
              value={movementFilter}
              onChange={(e) => setMovementFilter(e.target.value)}
            >
              <option value="">All Movements</option>
              <option value="IN">IN (Inward Stock)</option>
              <option value="OUT">OUT (Outward Stock)</option>
            </select>
          </div>
        </div>

        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Date & Time</th>
                <th>Product</th>
                <th>Movement Type</th>
                <th>Quantity</th>
                <th>Reason</th>
                <th>Logged By</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}>
                    <td colSpan={6}>
                      <div className="skeleton-box skeleton-row" />
                    </td>
                  </tr>
                ))
              ) : filteredMovements.length > 0 ? (
                filteredMovements.map((m) => {
                  const dateStr = new Date(m.createdAt).toLocaleString('en-IN', {
                    dateStyle: 'medium',
                    timeStyle: 'short',
                  });
                  const isIN = m.movementType === 'IN';
                  return (
                    <tr key={m.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: '#475569', fontSize: '0.8rem' }}>
                          <Calendar size={14} />
                          {dateStr}
                        </div>
                      </td>
                      <td>
                        <div style={{ fontWeight: 600 }}>{m.product?.name}</div>
                        <div style={{ fontSize: '0.75rem', color: '#64748b' }}>SKU: {m.product?.sku}</div>
                      </td>
                      <td>
                        <span className={`badge ${isIN ? 'badge-in' : 'badge-out'}`}>
                          {isIN ? <ArrowDownLeft size={13} /> : <ArrowUpRight size={13} />}
                          {m.movementType}
                        </span>
                      </td>
                      <td style={{ fontWeight: 700, fontSize: '0.95rem' }}>
                        {isIN ? `+${m.quantityChanged}` : `-${m.quantityChanged}`} units
                      </td>
                      <td style={{ fontSize: '0.85rem' }}>{m.reason}</td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                          <UserIcon size={14} color="#64748b" />
                          <span style={{ fontWeight: 500 }}>{m.createdBy?.name || 'System'}</span>
                        </div>
                        <div style={{ fontSize: '0.7rem', color: '#94a3b8' }}>{m.createdBy?.role}</div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="empty-state">
                    No stock movements recorded yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
