import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Building2, Lock, Mail, AlertCircle, ArrowRight } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      await login(email, password);
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check credentials.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const fillDemoAccount = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setError(null);
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <div className="login-icon">
            <Building2 size={28} />
          </div>
          <h2 className="login-title">ChocoDist</h2>
          <p className="login-subtitle">Chocolate Wholesale & Distribution Operations</p>
        </div>

        {error && (
          <div className="alert alert-danger">
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group" style={{ marginBottom: '1.25rem' }}>
            <label className="form-label">Email Address</label>
            <div className="search-input-wrapper" style={{ maxWidth: '100%' }}>
              <Mail className="search-icon" size={18} />
              <input
                type="email"
                className="search-input"
                placeholder="name@chocodist.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="form-group" style={{ marginBottom: '1.5rem' }}>
            <label className="form-label">Password</label>
            <div className="search-input-wrapper" style={{ maxWidth: '100%' }}>
              <Lock className="search-icon" size={18} />
              <input
                type="password"
                className="search-input"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            style={{ width: '100%', padding: '0.75rem' }}
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Authenticating...' : 'Sign In to Portal'}
            <ArrowRight size={18} />
          </button>
        </form>

        <div className="demo-account-box">
          <div className="demo-account-title">Interview Demo Accounts (1-Click Fill)</div>
          <div className="demo-buttons-grid">
            <button
              className="demo-btn"
              onClick={() => fillDemoAccount('admin@chocodist.com', 'ChocoAdmin#2026!A7')}
            >
              <span className="demo-btn-role">Admin</span>
              <span className="demo-btn-email">admin@chocodist.com</span>
            </button>
            <button
              className="demo-btn"
              onClick={() => fillDemoAccount('sales@chocodist.com', 'ChocoSales#2026!B8')}
            >
              <span className="demo-btn-role">Sales</span>
              <span className="demo-btn-email">sales@chocodist.com</span>
            </button>
            <button
              className="demo-btn"
              onClick={() => fillDemoAccount('warehouse@chocodist.com', 'ChocoWarehouse#2026!C9')}
            >
              <span className="demo-btn-role">Warehouse</span>
              <span className="demo-btn-email">warehouse@chocodist.com</span>
            </button>
            <button
              className="demo-btn"
              onClick={() => fillDemoAccount('accounts@chocodist.com', 'ChocoAccounts#2026!D4')}
            >
              <span className="demo-btn-role">Accounts</span>
              <span className="demo-btn-email">accounts@chocodist.com</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
